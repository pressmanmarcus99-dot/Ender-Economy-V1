# EnderEconomy — initial plugin project

This is a **starter implementation**, not yet the finished feature-complete plugin. It establishes the Paper plugin project and some working menu/command foundations. Do not treat every planned feature as complete.

## Requirements
- Java 21
- Maven 3.9+
- Paper server compatible with Minecraft 1.21.4
- Geyser on the server if Bedrock players (including an iPad) need to join

## Build
From this folder, run:

```bash
mvn package
```

The plugin JAR should appear at `target/EnderEconomy-0.1.0.jar`.

## Install
1. Stop your Paper server.
2. Copy `target/EnderEconomy-0.1.0.jar` into the server's `plugins` folder.
3. Start the server and check the console for `EnderEconomy enabled`.
4. Use `/balance`, `/pay`, `/ah`, `/sell`, `/stocks`, `/casino`, `/spawn`, `/tpa`, `/tpaccept`, `/tpdeny`, `/rtpa`, and `/rtps` to test the implemented foundations.
5. `/tpcasino` requires a casino location configured by an admin; setup tooling for that is not included yet.

## Important limitations in this build
- This source package has not been compiled or tested against a running Paper server in this environment.
- The Auction House listing creation UI, listing-slot purchases, admin configuration tools, full quantity selection, complete material buy/sell flows and restocking, dividends, company performance calculations, real company income sources, safe teleport edge cases, physical casino setup, and full data transaction safeguards still need implementation.
- The company directory currently uses placeholder names for most of the 30 companies; only The Ender Auction and a few examples are named.
- Auction fees are currently retained by the server; shareholder payouts to The Ender Auction are not implemented yet.
- `/rtpa` and `/rtps` currently use the same 10,000-block radius; the intended distinction needs to be finalized and implemented.
- The menu implementation uses chest inventories, but Bedrock/Geyser presentation and click behavior must be tested on the target server.

This project is a foundation for the requested plugin, not a claim that all agreed features are finished.
